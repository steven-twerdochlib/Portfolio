package com.example.moneyrecorder;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.InputType;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class FilterPopup extends AppCompatActivity {

    public static ArrayList<String> allNameFilters = new ArrayList<>();
    public static ArrayList<String> allCategoryFilters = new ArrayList<>();
    public static ArrayList<String> allPayeeFilters = new ArrayList<>();
    public static Double minAmountFilter;
    public static Double maxAmountFilter;
    public static String minDateFilter;
    public static String maxDateFilter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_filter_popup);

        LinearLayout scrollNameLinearLayout = findViewById(R.id.FilterNameSLayout);
        LinearLayout scrollCategoryLinearLayout = findViewById(R.id.FilterCategorySLayout);
        LinearLayout scrollPayeeLinearLayout = findViewById(R.id.FilterPayeeSLayout);

        ScrollView parentScrollView = findViewById(R.id.ParentScrollView);
        ScrollView nameScrollView = findViewById(R.id.NameScrollView);
        ScrollView categoryScrollView = findViewById(R.id.CategoryScrollView);
        ScrollView payeeScrollView = findViewById(R.id.PayeeScrollView);

        parentScrollView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                parentScrollView.requestDisallowInterceptTouchEvent(false);
                return false;
            }
        });

        nameScrollView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                // Disallow the touch request for parent scroll on touch of  child view
                parentScrollView.requestDisallowInterceptTouchEvent(true);
                return false;
            }
        });

        categoryScrollView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                // Disallow the touch request for parent scroll on touch of  child view
                parentScrollView.requestDisallowInterceptTouchEvent(true);
                return false;
            }
        });

        payeeScrollView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                // Disallow the touch request for parent scroll on touch of  child view
                parentScrollView.requestDisallowInterceptTouchEvent(true);
                return false;
            }
        });

        TextView filterMinDateTxtView = findViewById(R.id.FilterMinDateTxtView);
        TextView filterMaxDateTxtView = findViewById(R.id.FilterMaxDateTxtView);

        EditText filterMinAmountEditTxt = findViewById(R.id.FilterMinAmountEditTxt);
        filterMinAmountEditTxt.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus && !filterMinAmountEditTxt.getText().toString().equals("")) { {
                    DecimalFormat form = new DecimalFormat("0.00", new DecimalFormatSymbols(Locale.UK));
                    double a = Double.parseDouble(filterMinAmountEditTxt.getText().toString());
                    filterMinAmountEditTxt.setText(form.format(a));
                }
                }
            }});

        EditText filterMaxAmountEditTxt = findViewById(R.id.FilterMaxAmountEditTxt);
        filterMaxAmountEditTxt.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus && !filterMaxAmountEditTxt.getText().toString().equals("")) { {
                    DecimalFormat form = new DecimalFormat("0.00", new DecimalFormatSymbols(Locale.UK));
                    double a = Double.parseDouble(filterMaxAmountEditTxt.getText().toString());
                    filterMaxAmountEditTxt.setText(form.format(a));
                }
                }
            }});

        EditText filterNameEditTxt = findViewById(R.id.FilterNameEditTxt);
        filterNameEditTxt.setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                // If the event is a key-down event on the "enter" button
                if ((event.getAction() == KeyEvent.ACTION_DOWN) &&
                        (keyCode == KeyEvent.KEYCODE_ENTER)) {
                    // Perform action on key press
                    addToScrollLayout(filterNameEditTxt, scrollNameLinearLayout);
                    return true;
                }
                return false;
            }
        });

        EditText filterCategoryEditTxt = findViewById(R.id.FilterCategoryTxtView);
        filterCategoryEditTxt.setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                // If the event is a key-down event on the "enter" button
                if ((event.getAction() == KeyEvent.ACTION_DOWN) &&
                        (keyCode == KeyEvent.KEYCODE_ENTER)) {
                    // Perform action on key press
                    addToScrollLayout(filterCategoryEditTxt, scrollCategoryLinearLayout);
                    return true;
                }
                return false;
            }
        });

        EditText filterPayeeEditTxt = findViewById(R.id.FilterPayeeTxtView);
        filterPayeeEditTxt.setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                // If the event is a key-down event on the "enter" button
                if ((event.getAction() == KeyEvent.ACTION_DOWN) &&
                        (keyCode == KeyEvent.KEYCODE_ENTER)) {
                    // Perform action on key press
                    addToScrollLayout(filterPayeeEditTxt, scrollPayeeLinearLayout);
                    return true;
                }
                return false;
            }
        });

        ImageButton filterNameDeleteBtn = findViewById(R.id.FilterNameDeleteBtn);
        filterNameDeleteBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                scrollNameLinearLayout.removeAllViews();
            }
        });

        ImageButton filterCategoryDeleteBtn = findViewById(R.id.FilterCategoryDeleteBtn);
        filterCategoryDeleteBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                scrollCategoryLinearLayout.removeAllViews();
            }
        });

        ImageButton filterPayeeDeleteBtn = findViewById(R.id.FilterPayeeDeleteBtn);
        filterPayeeDeleteBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                scrollPayeeLinearLayout.removeAllViews();
            }
        });

        ImageButton filterMinDateDeleteBtn = findViewById(R.id.FilterMinDateDeleteBtn);
        filterMinDateDeleteBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                filterMinDateTxtView.setText("");
            }
        });

        ImageButton filterMaxDateDeleteBtn = findViewById(R.id.FilterMaxDateDeleteBtn);
        filterMaxDateDeleteBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                filterMaxDateTxtView.setText("");
            }
        });

        ImageButton filterMinAmountDeleteBtn = findViewById(R.id.FilterMinAmountDeleteBtn);
        filterMinAmountDeleteBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                filterMinAmountEditTxt.setText("");
            }
        });

        ImageButton filterMaxAmountDeleteBtn = findViewById(R.id.FilterMaxAmountDeleteBtn);
        filterMaxAmountDeleteBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                filterMaxAmountEditTxt.setText("");
            }
        });

        final Calendar myCalendar = Calendar.getInstance();
        String myFormat = "dd/MM/yyyy"; //In which you need put here
        DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            }
        };
        filterMinDateTxtView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(FilterPopup.this, date, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
                String myFormat = "dd/MM/yyyy"; //In which you need put here
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat);
                filterMinDateTxtView.setText(sdf.format(myCalendar.getTime()));
            }
        });
        filterMaxDateTxtView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(FilterPopup.this, date, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
                String myFormat = "dd/MM/yyyy"; //In which you need put here
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat);
                filterMaxDateTxtView.setText(sdf.format(myCalendar.getTime()));
            }
        });

        Button confirmBtn = findViewById(R.id.confirmBtn);
        confirmBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmBtnClicked();
            }
        });
    }

    private void addToScrollLayout(EditText editText, LinearLayout scrollLinearLayout){
        ScrollView parentScrollView = findViewById(R.id.ParentScrollView);
        Button deleteBtn = new Button(this);
        deleteBtn.setAllCaps(false);
        deleteBtn.setText(editText.getText());
        deleteBtn.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.button_image_x, 0);
        deleteBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
               scrollLinearLayout.removeView(deleteBtn);
            }
        });
        scrollLinearLayout.addView(deleteBtn);
        editText.setText("");

        deleteBtn.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                // Disallow the touch request for parent scroll on touch of  child view
                parentScrollView.requestDisallowInterceptTouchEvent(true);
                return false;
            }
        });
    }

    private void confirmBtnClicked(){
        ViewDatabase.filteredItemList.clear();

        LinearLayout scrollNameLinearLayout = findViewById(R.id.FilterNameSLayout);
        LinearLayout scrollCategoryLinearLayout = findViewById(R.id.FilterCategorySLayout);
        LinearLayout scrollPayeeLinearLayout = findViewById(R.id.FilterPayeeSLayout);

        TextView filterMinDateTxtView = findViewById(R.id.FilterMinDateTxtView);
        TextView filterMaxDateTxtView = findViewById(R.id.FilterMaxDateTxtView);

        EditText filterMinAmountEditTxt = findViewById(R.id.FilterMinAmountEditTxt);
        EditText filterMaxAmountEditTxt = findViewById(R.id.FilterMaxAmountEditTxt);

        String myFormat = "dd/MM/yyyy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat);

        Boolean filteredItem = false;
        for(int y = 0;y < ViewDatabase.itemList.size(); y++){
            for(int x = 0; x<scrollNameLinearLayout.getChildCount(); x++){
                Button childBtn = (Button) scrollNameLinearLayout.getChildAt(x);
                if(ViewDatabase.itemList.get(y).getItemName().equals(childBtn.getText().toString())){
                    filteredItem = true;
                }
            }
            for(int x = 0; x<scrollCategoryLinearLayout.getChildCount(); x++){
                Button childBtn = (Button) scrollCategoryLinearLayout.getChildAt(x);
                if(ViewDatabase.itemList.get(y).getItemCategory().equals(childBtn.getText().toString())){
                    filteredItem = true;
                }
            }
            for(int x = 0; x<scrollPayeeLinearLayout.getChildCount(); x++){
                Button childBtn = (Button) scrollPayeeLinearLayout.getChildAt(x);
                if(ViewDatabase.itemList.get(y).getPayee().equals(childBtn.getText().toString())){
                    filteredItem = true;
                }
            }
            if(!filterMinDateTxtView.getText().toString().equals("") && !filterMaxDateTxtView.getText().toString().equals("")){
                try {
                    Date tempMinDate = sdf.parse(filterMinDateTxtView.getText().toString());
                    Date tempMaxDate = sdf.parse(filterMaxDateTxtView.getText().toString());
                    Date tempItemxDate = sdf.parse(ViewDatabase.itemList.get(y).getDateBought());
                    if(tempItemxDate.after(tempMinDate) && tempItemxDate.before(tempMaxDate)){
                        filteredItem = true;
                    }
                } catch (ParseException e) { }
            }
            else if(filterMinDateTxtView.getText().toString().equals("") && !filterMaxDateTxtView.getText().toString().equals("")){
                try {
                    Date tempMaxDate = sdf.parse(filterMaxDateTxtView.getText().toString());
                    Date tempItemxDate = sdf.parse(ViewDatabase.itemList.get(y).getDateBought());
                    if(tempItemxDate.before(tempMaxDate)){
                        filteredItem = true;
                    }
                } catch (ParseException e) { }
            }
            else if(!filterMinDateTxtView.getText().toString().equals("") && filterMaxDateTxtView.getText().toString().equals("")){
                try {
                    Date tempMinDate = sdf.parse(filterMinDateTxtView.getText().toString());
                    Date tempItemxDate = sdf.parse(ViewDatabase.itemList.get(y).getDateBought());
                    if(tempItemxDate.after(tempMinDate)){
                        filteredItem = true;
                    }
                } catch (ParseException e) { }
            }
            if(!filterMinAmountEditTxt.getText().toString().equals("") && !filterMaxAmountEditTxt.getText().toString().equals("")){
                Double tempMinAmount = Double.parseDouble(filterMinAmountEditTxt.getText().toString());
                Double tempMaxAmount = Double.parseDouble(filterMaxAmountEditTxt.getText().toString());
                if(ViewDatabase.itemList.get(y).getItemCost() >= tempMinAmount && ViewDatabase.itemList.get(y).getItemCost() <= tempMaxAmount){
                    filteredItem = true;
                }
            }
            else if(filterMinAmountEditTxt.getText().toString().equals("") && !filterMaxAmountEditTxt.getText().toString().equals("")){
                Double tempMaxAmount = Double.parseDouble(filterMaxAmountEditTxt.getText().toString());
                if(ViewDatabase.itemList.get(y).getItemCost() <= tempMaxAmount){
                    filteredItem = true;
                }
            }
            else if(!filterMinAmountEditTxt.getText().toString().equals("") && filterMaxAmountEditTxt.getText().toString().equals("")){
                Double tempMinAmount = Double.parseDouble(filterMinAmountEditTxt.getText().toString());
                if(ViewDatabase.itemList.get(y).getItemCost() >= tempMinAmount){
                    filteredItem = true;
                }
            }
            if(filteredItem){
                ViewDatabase.filteredItemList.add(new ViewDatabase.ItemInteger(y, ViewDatabase.itemList.get(y)));
                filteredItem = false;
            }
        }
        ViewDatabase.filterConfirmedBtnClicked = true;
        System.out.println(ViewDatabase.filteredItemList.size());
        Intent intent = new Intent(this, ViewDatabase.class);
        startActivity(intent);
    }
}
