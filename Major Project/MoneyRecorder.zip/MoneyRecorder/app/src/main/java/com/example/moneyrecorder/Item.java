package com.example.moneyrecorder;

import java.util.Date;

public class Item {

    private String itemName;
    private String itemCategory;
    private String dateBought;
    private double itemCost;
    private String payee;
    private String paymentOption;

    public Item(String itemName, String itemCategory, String dateBought, double itemCost, String payee, String paymentOption) {
        this.itemName = itemName;
        this.itemCategory = itemCategory;
        this.dateBought = dateBought;
        this.itemCost = itemCost;
        this.payee = payee;
        this.paymentOption = paymentOption;
    }

    public String getItemName() {
        return itemName;
    }

    public String getItemCategory() {
        return itemCategory;
    }

    public String getDateBought() {
        return dateBought;
    }

    public double getItemCost() {
        return itemCost;
    }

    public String getPayee() {
        return payee;
    }

    public String getPaymentOption() {
        return paymentOption;
    }
}
