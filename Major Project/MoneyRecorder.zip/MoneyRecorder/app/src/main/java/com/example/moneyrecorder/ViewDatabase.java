package com.example.moneyrecorder;

import android.app.Activity;
import android.app.Service;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.method.ScrollingMovementMethod;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Locale;

public class ViewDatabase extends Activity {

    public static class ItemInteger {
        private Integer itemIndex;
        private Item item;

        public ItemInteger(Integer itemIndex, Item item) {
            this.itemIndex = itemIndex;
            this.item = item;
        }
    }

    public static ArrayList<Item> itemList = new ArrayList<>();
    public static ArrayList<ItemInteger> filteredItemList = new ArrayList<>();
    public static Boolean deleteBtnPressed = false;
    public static String tempFileContents;
    private View deleteBtnOnClickview;
    public static int deletedItemIndex;
    public static Boolean filterConfirmedBtnClicked = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_database);

        Button filterBtn = (Button) findViewById(R.id.filterBtn);
        filterBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(ViewDatabase.this, FilterPopup.class);
                startActivity(intent);
            }
        });
        sortFilteredList();
        createLayoutDynamically();

        if(deleteBtnPressed && !tempFileContents.equals(MainActivity.fileContents)){
            deleteBtnPressed = false;
            LinearLayout itemsLayout = findViewById(R.id.ItemsLayout);
            Button tmpBtn = new Button(this);
            tmpBtn.setVisibility(View.GONE);
            tmpBtn.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    findViewById(R.id.ViewDatabseLayout).post(new Runnable() {
                        public void run() {
                            cantDeleteItemPopup(v);
                        }
                    });
                }
            });
            itemsLayout.addView(tmpBtn);
            tmpBtn.performClick();
        }

        Button refreshBtn = findViewById(R.id.RefreshViewDbBtn);
        refreshBtn.setOnClickListener((new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(ViewDatabase.this, RetrieveContentsActivity.class);
                startActivity(intent);
            }
        }));
        /* //Runs AsyncTask which is currently not working.
        AsyncTaskRunner runner = new AsyncTaskRunner();
        runner.execute(MainActivity.fileContents);
        */
    }

    private void sortFilteredList(){
        //Filtered list is the same as item list.
        if(!filterConfirmedBtnClicked){
            filteredItemList.clear();
            for(int x=0; x<itemList.size(); x++){
                ItemInteger item = new ItemInteger(x, itemList.get(x));
                filteredItemList.add(item);
            }
        }
        else{
            filterConfirmedBtnClicked = false;
        }

        //Finds filters
        //TODO Find Filters.
    }

    private void createLayoutDynamically() {
        LinearLayout filterLayout = findViewById(R.id.FilterLayout);
        ImageButton filterDeleteBtn = new ImageButton(this);
        filterDeleteBtn.setImageDrawable(getResources().getDrawable(R.drawable.button_image_x));
        LinearLayout.LayoutParams filterDeleteBtnparams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.MATCH_PARENT
        );
        filterDeleteBtnparams.setMargins(0, 5, 5, 0);
        filterDeleteBtn.setLayoutParams(filterDeleteBtnparams);
        filterDeleteBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                LinearLayout allFiltersLayout = findViewById(R.id.AllFilterLayout);
                allFiltersLayout.removeAllViews();
            }
        });
        filterDeleteBtn.setVisibility(View.INVISIBLE);
        filterLayout.addView(filterDeleteBtn);

        for (int i = 0; i < filteredItemList.size(); i++) {
            System.out.println("Number of loops: " + i);
            LinearLayout itemsLayout = findViewById(R.id.ItemsLayout);


            final LinearLayout vLinearLayout = new LinearLayout(this);
            vLinearLayout.setId(i);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );
            params.setMargins(15, 15, 15, 15);
            vLinearLayout.setLayoutParams(params);
            vLinearLayout.setBackgroundResource(R.drawable.border);
            vLinearLayout.setOrientation(LinearLayout.VERTICAL);

            LinearLayout deleteBtnLayout = new LinearLayout(this);
            deleteBtnLayout.setOrientation(LinearLayout.HORIZONTAL);
            deleteBtnLayout.setGravity(Gravity.CENTER);
            deleteBtnLayout.setId(i);
            ImageButton deleteBtn = new ImageButton(this);
            deleteBtn.setImageDrawable(getResources().getDrawable(R.drawable.button_image_x));
            LinearLayout.LayoutParams deleteBtnparams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );
            deleteBtnparams.setMargins(15, 0, 0, 0);
            deleteBtn.setLayoutParams(deleteBtnparams);
            final TextView index = new TextView(this);
            index.setText(Integer.toString(i));
            deleteBtn.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    if(isOnline()){
                        tempFileContents = MainActivity.fileContents;
                        deleteBtnPressed = true;
                        deleteBtnOnClickview = v;
                        deletedItemIndex = Integer.parseInt(index.getText().toString());
                        Intent intent = new Intent(ViewDatabase.this, RetrieveContentsActivity.class);
                        startActivity(intent);
                    }
                    else {
                        tempFileContents = MainActivity.fileContents;
                        deleteBtnPressed = true;
                        deleteBtnOnClickview = v;
                        deletedItemIndex = Integer.parseInt(index.getText().toString());
                        noInternetPopupWindowClick(v);
                    }
                }
            });
            deleteBtnLayout.addView(deleteBtn);
            deleteBtnLayout.addView(vLinearLayout);
            itemsLayout.addView(deleteBtnLayout);


            final LinearLayout hLinearLayout = new LinearLayout(this);
            hLinearLayout.setId(i);
            hLinearLayout.setOrientation(LinearLayout.HORIZONTAL);
            hLinearLayout.setLayoutParams(params);
            vLinearLayout.addView(hLinearLayout);

            LinearLayout.LayoutParams paramsTextViews = new LinearLayout.LayoutParams(
                    0,
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    1.0f
            );
            paramsTextViews.setMargins(15, 0, 15, 0);

            final TextView itemBoughtTextView = new TextView(this);
            itemBoughtTextView.setId(i);
            itemBoughtTextView.setLayoutParams(paramsTextViews);
            itemBoughtTextView.setPadding(15, 0, 15, 0);
            itemBoughtTextView.setText(String.valueOf(filteredItemList.get(i).item.getItemName()));
            itemBoughtTextView.setHorizontallyScrolling(true);
            itemBoughtTextView.setMovementMethod(new ScrollingMovementMethod());
            itemBoughtTextView.setBackgroundResource(R.drawable.border);
            hLinearLayout.addView(itemBoughtTextView);

            final TextView itemCategoryTextView = new TextView(this);
            itemCategoryTextView.setId(i);
            itemCategoryTextView.setText(String.valueOf(filteredItemList.get(i).item.getItemCategory()));
            itemCategoryTextView.setHorizontallyScrolling(true);
            itemCategoryTextView.setMovementMethod(new ScrollingMovementMethod());
            itemCategoryTextView.setBackgroundResource(R.drawable.border);
            itemCategoryTextView.setLayoutParams(paramsTextViews);
            itemCategoryTextView.setPadding(15, 0, 15, 0);
            hLinearLayout.addView(itemCategoryTextView);

            final TextView itemCostTextView = new TextView(this);
            itemCostTextView.setId(i);
            DecimalFormat form = new DecimalFormat("0.00", new DecimalFormatSymbols(Locale.UK));
            double a = Double.parseDouble(String.valueOf(filteredItemList.get(i).item.getItemCost()));
            itemCostTextView.setText("£" + form.format(a));
            itemCostTextView.setHorizontallyScrolling(true);
            itemCostTextView.setMovementMethod(new ScrollingMovementMethod());
            itemCostTextView.setLayoutParams(paramsTextViews);
            itemCostTextView.setBackgroundResource(R.drawable.border);
            itemCostTextView.setPadding(15, 0, 15, 0);
            hLinearLayout.addView(itemCostTextView);

            LinearLayout secretLayout1 = new LinearLayout(this);
            secretLayout1.setOrientation(LinearLayout.HORIZONTAL);
            secretLayout1.setLayoutParams(params);
            secretLayout1.setVisibility(View.GONE);
            vLinearLayout.addView(secretLayout1);

            final TextView dateTextView = new TextView(this);
            dateTextView.setId(i);
            LinearLayout.LayoutParams paramsDateTextViews = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );
            paramsDateTextViews.setMargins(15, 0, 15, 0);
            dateTextView.setLayoutParams(paramsDateTextViews);
            dateTextView.setPadding(15, 0, 15, 0);
            dateTextView.setText(String.valueOf(filteredItemList.get(i).item.getDateBought()));
            dateTextView.setHorizontallyScrolling(true);
            dateTextView.setMovementMethod(new ScrollingMovementMethod());
            dateTextView.setBackgroundResource(R.drawable.border);
            secretLayout1.addView(dateTextView);

            final TextView payeeTextView = new TextView(this);
            payeeTextView.setId(i);
            payeeTextView.setText(String.valueOf(filteredItemList.get(i).item.getPayee()));
            payeeTextView.setHorizontallyScrolling(true);
            payeeTextView.setMovementMethod(new ScrollingMovementMethod());
            payeeTextView.setBackgroundResource(R.drawable.border);
            payeeTextView.setLayoutParams(paramsTextViews);
            payeeTextView.setPadding(15, 0, 15, 0);
            secretLayout1.addView(payeeTextView);

            LinearLayout secretLayout2 = new LinearLayout(this);
            secretLayout2.setOrientation(LinearLayout.HORIZONTAL);
            secretLayout2.setLayoutParams(params);
            secretLayout2.setVisibility(View.GONE);
            vLinearLayout.addView(secretLayout2);

            final TextView payOptTextView = new TextView(this);
            payOptTextView.setId(i);
            payOptTextView.setText(filteredItemList.get(i).item.getPaymentOption());
            payOptTextView.setHorizontallyScrolling(true);
            payOptTextView.setMovementMethod(new ScrollingMovementMethod());
            payOptTextView.setLayoutParams(paramsTextViews);
            payOptTextView.setBackgroundResource(R.drawable.border);
            payOptTextView.setPadding(15, 0, 15, 0);
            secretLayout2.addView(payOptTextView);

            final Button myButton = new Button(this);
            myButton.setId(i);
            myButton.setText(R.string.see_more_info);
            myButton.setBackgroundResource(R.drawable.buttonborder);
            myButton.setLayoutParams(params);
            vLinearLayout.addView(myButton);

            myButton.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    if(secretLayout1.getVisibility() == View.GONE){
                        secretLayout1.setVisibility(View.VISIBLE);
                        secretLayout2.setVisibility(View.VISIBLE);
                    }
                    else{
                        secretLayout1.setVisibility(View.GONE);
                        secretLayout2.setVisibility(View.GONE);
                    }

                }
            });
        }

    }

    public void filterPopup(View view) {
        // inflate the layout of the popup window
        LayoutInflater inflater = (LayoutInflater)
                getSystemService(LAYOUT_INFLATER_SERVICE);
        View popupView = inflater.inflate(R.layout.activity_filter_popup, null);

        // create the popup window
        int width = LinearLayout.LayoutParams.WRAP_CONTENT;
        int height = LinearLayout.LayoutParams.WRAP_CONTENT;
        boolean focusable = true; // lets taps outside the popup also dismiss it
        final PopupWindow popupWindow = new PopupWindow(popupView, width, height, focusable);

        // show the popup window
        // which view you pass in doesn't matter, it is only used for the window tolken
        popupWindow.showAtLocation(view, Gravity.CENTER, 0, 0);
        Button confirmBtn = (Button) popupView.findViewById(R.id.confirmBtn);
        confirmBtn.setOnClickListener(new View.OnClickListener() {

            public void onClick(View popupView) {
                popupWindow.dismiss();
            }
        });
    }

    public void cantDeleteItemPopup(View view) {
        // inflate the layout of the popup window
        LayoutInflater inflater = (LayoutInflater)
                getSystemService(LAYOUT_INFLATER_SERVICE);
        View popupView = inflater.inflate(R.layout.activity_cant_delet_item_popup, null);

        // create the popup window
        int width = LinearLayout.LayoutParams.WRAP_CONTENT;
        int height = LinearLayout.LayoutParams.WRAP_CONTENT;
        boolean focusable = true; // lets taps outside the popup also dismiss it
        final PopupWindow popupWindow = new PopupWindow(popupView, width, height, focusable);

        // show the popup window
        // which view you pass in doesn't matter, it is only used for the window tolken
        popupWindow.showAtLocation(view, Gravity.CENTER, 0, 0);
        Button confirmBtn = (Button) popupView.findViewById(R.id.confirmBtn);
        confirmBtn.setOnClickListener(new View.OnClickListener() {

            public void onClick(View popupView) {
                popupWindow.dismiss();
            }
        });
    }

    //The below function was taken from: https://stackoverflow.com/questions/1560788/how-to-check-internet-access-on-android-inetaddress-never-times-out
    //This function is used to return a Boolean on whether there is a working internet connection on the device.
    public boolean isOnline() {
        Runtime runtime = Runtime.getRuntime();
        try {
            Process ipProcess = runtime.exec("/system/bin/ping -c 1 8.8.8.8");
            int     exitValue = ipProcess.waitFor();
            return (exitValue == 0);
        }
        catch (IOException e)          { e.printStackTrace(); }
        catch (InterruptedException e) { e.printStackTrace(); }

        return false;
    }

    public void noInternetPopupWindowClick(View view) {
        // inflate the layout of the popup window
        LayoutInflater inflater = (LayoutInflater)
                getSystemService(LAYOUT_INFLATER_SERVICE);
        View popupView = inflater.inflate(R.layout.activity_no_internet_popup, null);

        // create the popup window
        int width = LinearLayout.LayoutParams.WRAP_CONTENT;
        int height = LinearLayout.LayoutParams.WRAP_CONTENT;
        boolean focusable = true; // lets taps outside the popup also dismiss it
        final PopupWindow popupWindow = new PopupWindow(popupView, width, height, focusable);

        // show the popup window
        // which view you pass in doesn't matter, it is only used for the window tolken
        popupWindow.showAtLocation(view, Gravity.CENTER, 0, 0);
        Button noBtn = (Button) popupView.findViewById(R.id.NoBtn);

        noBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View popupView) {
                popupWindow.dismiss();
            }
        });

        Button yesBtn = (Button) popupView.findViewById(R.id.YesBtn);

        yesBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View popupView) {
                Intent intent = new Intent(ViewDatabase.this, RetrieveContentsActivity.class);
                startActivity(intent);
                popupWindow.dismiss();
            }
        });
    }

    public void onBackPressed(){
        startActivity(new Intent(this, MainActivity.class));
    }

    /* /* Attempt at making a constantly checking whether the file/database has been update.
    //Code fails because when calling the class RetrieveContentsActivity, the class does not get the correct file contents or because code doesn't
    //get/set the file contents stored in Main Acitivity successfully.

    private class AsyncTaskRunner extends AsyncTask<String, String, String[]>{

        @Override
        protected String[] doInBackground(String... previousFileContents) {
            return previousFileContents;
        }

        @Override
        protected void onProgressUpdate(String... values) {
        }

        @Override
        protected void onPostExecute(String[] previousFileContents) {
            // execution of result of Long time consuming operation

            Intent intent = new Intent(ViewDatabase.this, RetrieveContentsActivity.class);
            startService(intent);
            Boolean result;
            String previousFileContent = MainActivity.getFileContents();
            String newFileContents = RetrieveContentsActivity.getmFileContents();
            if(!newFileContents.equals(previousFileContent)) {
                result = true;
                System.out.println(true);
            }
            else{
                result = false;
            }
            if(result){
                Button refreshBtn = findViewById(R.id.refreshBtn);
                refreshBtn.setVisibility(View.VISIBLE);
            }
            AsyncTaskRunner runner = new AsyncTaskRunner();
            runner.execute(MainActivity.fileContents);
        }
    }
    */
}
