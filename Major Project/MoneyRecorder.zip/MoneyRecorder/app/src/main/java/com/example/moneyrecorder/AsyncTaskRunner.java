package com.example.moneyrecorder;

interface AsyncTaskRunner {
}
