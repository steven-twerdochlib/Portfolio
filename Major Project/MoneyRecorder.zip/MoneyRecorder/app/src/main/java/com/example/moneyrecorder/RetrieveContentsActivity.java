/*
 * Copyright 2013 Google Inc. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the
 * License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.example.moneyrecorder;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.google.android.gms.drive.DriveContents;
import com.google.android.gms.drive.DriveFile;
import com.google.android.gms.drive.Metadata;
import com.google.android.gms.tasks.Task;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URL;

/**
 * Activity to illustrate how to retrieve and read file contents.
 */
// Some of this class code was taken from https://github.com/gsuitedevs/android-samples/tree/master/drive/demos/app/src/main/java/com/google/android/gms/drive/sample/demo
// However, some changes have been made to make the code suit this app, Money Record.
public class RetrieveContentsActivity extends BaseDemoActivity {
    private static final String TAG = "RetrieveContents";

    private static String mFileContents;

    @Override
    protected void onDriveClientReady() {
        if(MainActivity.currentDb == null){
            pickTextFile()
                    .addOnSuccessListener(this,
                            driveId -> retrieveContents(driveId.asDriveFile()))
                    .addOnFailureListener(this, e -> {
                        Log.e(TAG, "No file selected", e);
                        showMessage(getString(R.string.file_not_selected));
                        finish();
                    });
        }
        else{
            retrieveContents(MainActivity.currentDb.asDriveFile());
        }
    }

    public void retrieveContents(DriveFile file) {
        // [START drive_android_open_file]
        Task<DriveContents> openFileTask =
                getDriveResourceClient().openFile(file, DriveFile.MODE_READ_ONLY);
        // [END drive_android_open_file]
        // [START drive_android_read_contents]
        openFileTask
                .continueWithTask(task -> {
                    DriveContents contents = task.getResult();
                    // Process contents...
                    // [START_EXCLUDE]
                    // [START drive_android_read_as_string]
                    try (BufferedReader reader = new BufferedReader(
                                 new InputStreamReader(contents.getInputStream()))) {
                        StringBuilder builder = new StringBuilder();
                        String line;
                        while ((line = reader.readLine()) != null) {
                            builder.append(line).append("\n");
                        }

                        mFileContents = builder.toString();
                        showMessage(getString(R.string.content_loaded));
                    }
                    stringToItemsArray();

                    Task<Metadata> getMetadataTask = getDriveResourceClient().getMetadata(file);
                    getMetadataTask
                            .addOnSuccessListener(this,
                                    metadata -> {
                                        MainActivity.currentDbTitle = metadata.getTitle();
                                        finish();
                                    })
                            .addOnFailureListener(this, e -> {
                                Log.e(TAG, "Unable to retrieve metadata", e);
                                showMessage(getString(R.string.read_failed));
                                finish();
                            });

                    // [END drive_android_read_as_string]
                    // [END_EXCLUDE]
                    // [START drive_android_discard_contents]
                    Task<Void> discardTask = getDriveResourceClient().discardContents(contents);
                    // [END drive_android_discard_contents]
                    MainActivity.currentDb = file.getDriveId();
                    MainActivity.setFileContents(mFileContents);
                    if(MainActivity.submitBtnClicked){
                        MainActivity.fileContents = mFileContents.concat(AddItems.inputsToStringResult);
                        Intent intent = new Intent(this, RewriteContentsActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                        startActivity(intent);
                        finish();
                    }
                    else if(ViewDatabase.deleteBtnPressed){
                        if(ViewDatabase.tempFileContents.equals(MainActivity.fileContents)){
                            String[] lines = MainActivity.fileContents.split("\\r?\\n");
                            MainActivity.fileContents = "";
                            for(int x = 0; x < (lines.length/6); x++){
                                System.out.println("Index: "+ (((ViewDatabase.itemList.size()-1) - (ViewDatabase.deletedItemIndex)) * 6));
                                if(x == ((ViewDatabase.itemList.size()-1) - (ViewDatabase.deletedItemIndex))){
                                }
                                else{
                                    MainActivity.fileContents = MainActivity.fileContents.concat(lines[0+(x*6)] + "\n" + lines[1+(x*6)]+ "\n"  +
                                            lines[2+(x*6)]+ "\n" + lines[3+(x*6)] + "\n"  + lines[4+(x*6)] + "\n"  + lines[5+(x*6)] + "\n" );
                                }
                            }
                            Intent intent = new Intent(this, RewriteContentsActivity.class);
                            startActivity(intent);
                        }
                        else{
                            Intent intent = new Intent(this, ViewDatabase.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                            startActivity(intent);
                            finish();
                        }
                    }
                    else{
                        Intent intent = new Intent(this, ViewDatabase.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                        startActivity(intent);
                        finish();
                    }
                    return discardTask;
                })
                .addOnFailureListener(e -> {
                    // Handle failure
                    // [START_EXCLUDE]
                    Log.e(TAG, "Unable to read contents", e);
                    showMessage(getString(R.string.read_failed));
                    finish();
                    // [END_EXCLUDE]
                });
        // [END drive_android_read_contents]
    }

    private void stringToItemsArray(){
        ViewDatabase.itemList.clear();
        String[] lines = mFileContents.split("\\r?\\n");
        for(int x = 0; x < (lines.length/6); x++){
            Item item = new Item(lines[(0+(6*x))], lines[1+(6*x)], lines[4+(6*x)],
                    Double.parseDouble(lines[2+(6*x)].substring(1)), lines[3+(6*x)], lines[5+(6*x)]);
            ViewDatabase.itemList.add(0, item); //Index 0 so newest additions are displayed first when viewing the items.
        }
    }
}
