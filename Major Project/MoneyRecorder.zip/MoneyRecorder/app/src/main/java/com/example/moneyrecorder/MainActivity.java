package com.example.moneyrecorder;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.drive.DriveId;

public class MainActivity extends AppCompatActivity {

    private static Boolean loadedData = false;
    public static String newFileName;
    public static DriveId currentDb;
    public static String currentDbTitle;
    public static String fileContents = "";
    public static Boolean submitBtnClicked = false;
    public static String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Makes sure data is loaded only once on start up
        if(!loadedData){
            loadData();
            loadedData = true;
        }

        final LinearLayout signOutLayout = (LinearLayout) findViewById(R.id.SignoutLayout);
        final LinearLayout viewCurrLayout = (LinearLayout) findViewById(R.id.ViewCurrLayout);
        final LinearLayout addCurrLayout = (LinearLayout) findViewById(R.id.AddCurrLayout);
        final TextView viewDbTxtView = (TextView) findViewById(R.id.ViewDbTxtView);
        final TextView addDbTxtView = (TextView) findViewById(R.id.AddDbTxtView);
        final TextView userTxtView = (TextView) findViewById(R.id.userTextView);

        if(userTxtView != null){
            userTxtView.setText(username);
        }

        Button AddCurrBtn = (Button) findViewById(R.id.AddCurrBtn);
        AddCurrBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, AddItems.class));
            }
        });

        Button AddDiffBtn = (Button) findViewById(R.id.AddDiffBtn);
        AddDiffBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                currentDb = null;
                startActivity(new Intent(MainActivity.this, RewriteContentsActivity.class));
            }
        });

        Button viewCurrBtn = (Button) findViewById(R.id.ViewCurrentBtn);
        viewCurrBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), RetrieveContentsActivity.class);
                startActivity(intent);
                //startActivity(new Intent(MainActivity.this, ViewDatabase.class));
            }
        });

        Button viewDiffBtn = (Button) findViewById(R.id.ViewDiffBtn);
        viewDiffBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                currentDb = null;
                Intent intent = new Intent(getBaseContext(), RetrieveContentsActivity.class);
                startActivity(intent);
            }
        });

        Button newFileBtn = (Button) findViewById(R.id.CreateNewBtn);
        newFileBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                ConfirmPopupWindowClick(v);
            }
        });

        final Button signOutBtn = (Button) findViewById(R.id.signOutBtn);
        signOutBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                LinearLayout signOutLayout = (LinearLayout) findViewById(R.id.SignoutLayout);
                signOutLayout.setVisibility(View.GONE);
                Intent intent = new Intent(getBaseContext(), SignOut.class);
                startActivity(intent);
            }
        });

        if(username == null){
            signOutLayout.setVisibility(View.GONE);
        }
        if(currentDb == null){
            addCurrLayout.setVisibility(View.GONE);
            viewCurrLayout.setVisibility(View.GONE);
        }
        else{
            addCurrLayout.setVisibility(View.VISIBLE);
            viewCurrLayout.setVisibility(View.VISIBLE);
            addDbTxtView.setText(currentDbTitle);
            viewDbTxtView.setText(currentDbTitle);
        }
    }

    public static void setFileContents(String fileContents) {
        MainActivity.fileContents = fileContents;
    }

    public static String getFileContents() {
        return fileContents;
    }

    public void ConfirmPopupWindowClick(View view) {
        // inflate the layout of the popup window
        LayoutInflater inflater = (LayoutInflater)
                getSystemService(LAYOUT_INFLATER_SERVICE);
        View popupView = inflater.inflate(R.layout.activity_new_file_popup, null);

        // create the popup window
        int width = LinearLayout.LayoutParams.WRAP_CONTENT;
        int height = LinearLayout.LayoutParams.WRAP_CONTENT;
        boolean focusable = true; // lets taps outside the popup also dismiss it
        final PopupWindow popupWindow = new PopupWindow(popupView, width, height, focusable);

        // show the popup window
        popupWindow.showAtLocation(view, Gravity.CENTER, 0, 0);
        Button confirmBtn = (Button) popupView.findViewById(R.id.confirmBtn);

        EditText fileNameEditTxt = popupView.findViewById(R.id.fileNameEditText);
        confirmBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View popupView) {
                newFileName = fileNameEditTxt.getText().toString();
                popupWindow.dismiss();
                Intent intent = new Intent(getBaseContext(), CreateFileActivity.class);
                startActivity(intent);
            }
        });
    }

    //When the app closes the following function is called.
    @Override
    protected void onStop(){
        super.onStop();
        // Creating a shared pref object
        // with a file name "MySharedPref" in private mode
        SharedPreferences sharedPreferences
                = getSharedPreferences("MySharedPref",
                MODE_PRIVATE);
        SharedPreferences.Editor myEdit = sharedPreferences.edit();
        myEdit.putString("Username", username);
        if(currentDb != null){
            myEdit.putString("DriverId", currentDb.encodeToString());
        }
        if(AddItems.allPaymentOptions != null){
            String tempAllPaymentOpt = "";
            for(String paymentOpt: AddItems.allPaymentOptions){
                tempAllPaymentOpt = tempAllPaymentOpt + paymentOpt + "\n";
            }
            myEdit.putString("All Payment Options", tempAllPaymentOpt);
        }
        myEdit.putString("File Contents", fileContents);
        myEdit.putString("File Title", currentDbTitle);
        myEdit.commit();
    }

    // when the app opens again
    protected void loadData()
    {
        // Fetching the stored data
        // from the SharedPreference
        SharedPreferences sh = getSharedPreferences("MySharedPref", MODE_PRIVATE);

        username = sh.getString("Username", null);
        String tempCurrentDb = sh.getString("DriverId", "");
        if(!tempCurrentDb.equals("")){
            currentDb = DriveId.decodeFromString(tempCurrentDb);
        }
        if(AddItems.allPaymentOptions.size() == 0){
            String[] tempList = sh.getString("All Payment Options", "").split("\\r?\\n");
            for(String tempString: tempList){
                if(!tempString.equals("")){
                    AddItems.allPaymentOptions.add(tempString);
                }
            }
            if(AddItems.allPaymentOptions.size() != 0){
                AddItems.allPaymentOptions.remove(AddItems.allPaymentOptions.size() - 1);
            }
        }
        fileContents = sh.getString("File Contents", "");
        currentDbTitle = sh.getString("File Title", "");
    }
}
