package com.example.moneyrecorder;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.method.ScrollingMovementMethod;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.Scroller;
import android.widget.TextView;

import com.google.android.gms.vision.text.Line;

import java.io.IOException;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class AddItems extends AppCompatActivity {

    private RecyclerView.Adapter mAdapter;
    public static String addedItemsString = "";
    public static String inputsToStringResult = "";
    public String paymentOpt = "Cash";
    public static ArrayList<String> allPaymentOptions = new ArrayList<String>();
    private Boolean paymentOptLoaded = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_items);

        //Restore previously made payment options
        if(!paymentOptLoaded){
            for(String paymentOptString: allPaymentOptions){
                if(!paymentOptString.equals("")){
                    createPaymentOpt(paymentOptString);
                }
            }
            createPaymentOpt("Cash");
            paymentOptLoaded = true;
        }

        //Restores previously made items.
        if(!addedItemsString.equals("")){
            String[] lines = addedItemsString.split("\\r?\\n");
            for(int x = 0; x < (lines.length/6); x++){
                Item item = new Item(lines[(0+(6*x))], lines[1+(6*x)], lines[2+(6*x)],
                        Double.parseDouble(lines[3+(6*x)].substring(1)), lines[4+(6*x)], lines[5+(6*x)]);
                addCurrentItems(item.getPaymentOption(), item.getDateBought(), item.getPayee(), item.getItemName(), item.getItemCategory(), Double.toString(item.getItemCost()));
            }
        }

        //Attempt at making sn infinite scroll option for payment types
        /*
        mDataset.add("Cash");
        mDataset.add("Santander");
        mDataset.add("Nationwide");
        mDataset.add("Testing 1223344343141");
        final LinearLayoutManager layoutManager
                = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        RecyclerView payOptRecylcleView = (RecyclerView) findViewById(R.id.PaymentOptionScroll);
        payOptRecylcleView.setLayoutManager(layoutManager);
        mAdapter = new MyAdaptor(this, mDataset);
        payOptRecylcleView.setAdapter(mAdapter);
        */

        //Sorts out the payment option layouts.
        TextView cashPayOptTextView = (TextView) findViewById(R.id.CashPayOptTextView);
        cashPayOptTextView.setBackgroundResource(R.drawable.border);
        cashPayOptTextView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                cashPayOptTextView.setBackgroundResource(R.drawable.border);
                LinearLayout paymentOptLayout = (LinearLayout) findViewById(R.id.PaymentOptLayout);
                for(int x = 1; x < paymentOptLayout.getChildCount() - 1; x++){  //not including first TextView Cash and last Button that adds payment options.
                    LinearLayout tempLayout = (LinearLayout) paymentOptLayout.getChildAt(x);
                    TextView tempTextView = (TextView) tempLayout.getChildAt(0);
                    tempTextView.setBackgroundResource(0);
                }
                paymentOpt = "Cash";
            }
        });
        Button addPayOptBtn = (Button) findViewById(R.id.AddPayOptBtn);
        addPayOptBtn .setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                ConfirmPopupWindowClick(v);
            }
        });

        Button addItemBtn = (Button) findViewById(R.id.AddItemBtn);
        addItemBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(checkInputs()){
                    TextView dateEditTxt = (TextView) findViewById(R.id.DateTextView);
                    EditText payeeEditTxt = (EditText) findViewById(R.id.PayeeEditTxt);
                    EditText itemBoughtEditTxt = (EditText) findViewById(R.id.ItemBoughtEditTxt);
                    EditText itemCategoryEditTxt = (EditText) findViewById(R.id.ItemCategoryEditTxt);
                    EditText amountEditTxt = (EditText) findViewById(R.id.AmountEditTxt);
                    addedItemsString = addedItemsString.concat(itemBoughtEditTxt.getText().toString() + "\n" + itemCategoryEditTxt.getText().toString() + "\n" + dateEditTxt.getText().toString()
                    + "\n£" + amountEditTxt.getText().toString() + "\n" + payeeEditTxt.getText().toString() + "\n" + paymentOpt + "\n");
                    addCurrentItems(paymentOpt, dateEditTxt.getText().toString(), payeeEditTxt.getText().toString(),
                            itemBoughtEditTxt.getText().toString(), itemCategoryEditTxt.getText().toString(), amountEditTxt.getText().toString());
                    clearAllInputs();
                }
            }
        });

        //Makes the clear buttons work as intended when clicked
        TextView dateTextView= (TextView) findViewById(R.id.DateTextView);
        EditText payeeEditTxt = (EditText) findViewById(R.id.PayeeEditTxt);
        EditText itemBoughtEditTxt = (EditText) findViewById(R.id.ItemBoughtEditTxt);
        EditText itemCategoryEditTxt = (EditText) findViewById(R.id.ItemCategoryEditTxt);
        EditText amountEditTxt = (EditText) findViewById(R.id.AmountEditTxt);

        final Calendar myCalendar = Calendar.getInstance();
        String myFormat = "dd/MM/yyyy"; //In which you need put here
        Date currentDate = new Date(System.currentTimeMillis());
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat);
        dateTextView.setText(sdf.format(currentDate));
        DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                String myFormat = "dd/MM/yyyy"; //In which you need put here
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat);
                dateTextView.setText(sdf.format(myCalendar.getTime()));
            }
        };
        dateTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(AddItems.this, date, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        ImageButton payeeClearBtn = (ImageButton) findViewById(R.id.PayeeClearBtn);
        payeeClearBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                payeeEditTxt.setText("");
            }
        });
        ImageButton itemNameClearBtn = (ImageButton) findViewById(R.id.ItemNameClearBtn);
        itemNameClearBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                itemBoughtEditTxt.setText("");
            }
        });
        ImageButton itemCateClearBtn = (ImageButton) findViewById(R.id.ItemCateClearBtn);
        itemCateClearBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                itemCategoryEditTxt.setText("");
            }
        });
        ImageButton amountClearBtn = (ImageButton) findViewById(R.id.AmountClearBtn);
        amountClearBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                amountEditTxt.setText("");
            }
        });

        amountEditTxt.setOnFocusChangeListener(new View.OnFocusChangeListener() {

            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus && !amountEditTxt.getText().toString().equals("")) { {
                    DecimalFormat form = new DecimalFormat("0.00", new DecimalFormatSymbols(Locale.UK));
                    double a = Double.parseDouble(amountEditTxt.getText().toString());
                    amountEditTxt.setText(form.format(a));
                }
                }
            }});

        //Makes the submit button and scan barcode button work as intended.
        Button scanBarcodeBtn = (Button) findViewById(R.id.ScanBarcodeBtn);
        scanBarcodeBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivityForResult(new Intent(AddItems.this, ScannedBarcodeActivity.class), 1);
            }
        });
        Button submitBtn = (Button) findViewById(R.id.SubmitBtn);
        submitBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(isOnline()){
                    addedItemsString = "";
                    MainActivity.submitBtnClicked = true;
                    inputsToStringResult = inputsToString();
                    startActivity(new Intent(AddItems.this, RetrieveContentsActivity.class));
                }
                else{
                    noInternetPopupWindowClick(v);
                }
            }
        });
    }

    private Boolean checkInputs(){
        TextView dateEditTxt = (TextView) findViewById(R.id.DateTextView);
        EditText payeeEditTxt = (EditText) findViewById(R.id.PayeeEditTxt);
        EditText itemBoughtEditTxt = (EditText) findViewById(R.id.ItemBoughtEditTxt);
        EditText itemCategoryEditTxt = (EditText) findViewById(R.id.ItemCategoryEditTxt);
        EditText amountEditTxt = (EditText) findViewById(R.id.AmountEditTxt);
        Boolean invalidInputFound = false;

        if(dateEditTxt.getText().toString().equals("") || dateEditTxt.getText() == null){
            invalidInputFound = true;
            dateEditTxt.setBackgroundResource(R.drawable.invalid_input);
        }
        else{
            dateEditTxt.setBackgroundResource(R.drawable.border);
        }
        if(payeeEditTxt.getText().toString().equals("")){
            invalidInputFound = true;
            payeeEditTxt.setBackgroundResource(R.drawable.invalid_input);
        }
        else{
            payeeEditTxt.setBackgroundResource(R.drawable.border);
        }
        if(itemBoughtEditTxt .getText().toString().equals("")){
            invalidInputFound = true;
            itemBoughtEditTxt .setBackgroundResource(R.drawable.invalid_input);
        }
        else{
            itemBoughtEditTxt.setBackgroundResource(R.drawable.border);
        }
        if(itemCategoryEditTxt.getText().toString().equals("")){
            invalidInputFound = true;
            itemCategoryEditTxt.setBackgroundResource(R.drawable.invalid_input);
        }
        else{
            itemCategoryEditTxt.setBackgroundResource(R.drawable.border);
        }
        if(amountEditTxt.getText().toString().equals("")){
            invalidInputFound = true;
            amountEditTxt.setBackgroundResource(R.drawable.invalid_input);
        }
        else{
            amountEditTxt.setBackgroundResource(R.drawable.border);
        }

        if(invalidInputFound){
            return false;
        }
        else{
            return true;
        }
    }

    private void clearAllInputs(){
        EditText payeeEditTxt = (EditText) findViewById(R.id.PayeeEditTxt);
        EditText itemBoughtEditTxt = (EditText) findViewById(R.id.ItemBoughtEditTxt);
        EditText itemCategoryEditTxt = (EditText) findViewById(R.id.ItemCategoryEditTxt);
        EditText amountEditTxt = (EditText) findViewById(R.id.AmountEditTxt);

        payeeEditTxt.setText("");
        itemBoughtEditTxt.setText("");
        itemCategoryEditTxt.setText("");
        amountEditTxt.setText("");
    }

    public void addCurrentItems(String paymentOptString, String dateString, String payeeString, String itemBoughtString,
                                String itemCategoryString, String amountString){

        LinearLayout allAddedItemsLayout = (LinearLayout) findViewById(R.id.AllAddedItemsLayout);

        LinearLayout.LayoutParams paramsDeleteBtn = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );

        LinearLayout.LayoutParams paramsTextViews = new LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.MATCH_PARENT,
                1.0f
        );

        final LinearLayout hLinearLayout = new LinearLayout(this);
        hLinearLayout.setOrientation(LinearLayout.HORIZONTAL);

        ImageButton deleteBtn = new ImageButton(this);
        deleteBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                LinearLayout parentLayout = (LinearLayout) hLinearLayout.getParent();
                allAddedItemsLayout.removeView(hLinearLayout);
                addedItemsString = "";
                for(int x=0; x<parentLayout.getChildCount(); x++){
                    LinearLayout childLayout = (LinearLayout) parentLayout.getChildAt(x);
                    LinearLayout childItemLayout = (LinearLayout) childLayout.getChildAt(1);
                    TextView itemNameTxt = (TextView) childItemLayout.getChildAt(0);
                    TextView itemCateTxt = (TextView) childItemLayout.getChildAt(1);
                    TextView itemCostTxt = (TextView) childItemLayout.getChildAt(2);
                    TextView itemPayeeTxt = (TextView) childItemLayout.getChildAt(3);
                    TextView itemDateTxt = (TextView) childItemLayout.getChildAt(4);
                    TextView itemPayOptTxt = (TextView) childItemLayout.getChildAt(5);

                    addedItemsString = addedItemsString + itemNameTxt.getText().toString() + "\n" + itemCateTxt.getText().toString()  + "\n" + itemDateTxt.getText().toString()
                            + "\n" + itemCostTxt.getText().toString() + "\n" + itemPayeeTxt.getText().toString() + "\n" + itemPayOptTxt.getText().toString() + "\n";
                }
            }
        });
        paramsDeleteBtn.setMargins(15, 0, 0, 15);
        deleteBtn.setLayoutParams(paramsDeleteBtn);
        deleteBtn.setScaleType(ImageView.ScaleType.FIT_CENTER);
        deleteBtn.setImageDrawable(getResources().getDrawable(R.drawable.button_image_x));
        hLinearLayout.addView(deleteBtn);

        final LinearLayout hLinearLayoutItemInfo = new LinearLayout(this);
        hLinearLayoutItemInfo.setTag("Item Info");
        hLinearLayoutItemInfo.setOrientation(LinearLayout.HORIZONTAL);
        hLinearLayoutItemInfo.setBackgroundResource(R.drawable.buttonborder);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        params.setMargins(0, 25, 15, 0);
        hLinearLayoutItemInfo.setLayoutParams(params);
        hLinearLayoutItemInfo.setGravity(Gravity.CENTER);
        hLinearLayoutItemInfo.isClickable();
        hLinearLayoutItemInfo.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                TextView dateEditTxt = (TextView) findViewById(R.id.DateTextView);
                EditText payeeEditTxt = (EditText) findViewById(R.id.PayeeEditTxt);
                EditText itemBoughtEditTxt = (EditText) findViewById(R.id.ItemBoughtEditTxt);
                EditText itemCategoryEditTxt = (EditText) findViewById(R.id.ItemCategoryEditTxt);
                EditText amountEditTxt = (EditText) findViewById(R.id.AmountEditTxt);

                TextView dateTxtView = (TextView) hLinearLayoutItemInfo.getChildAt(4);
                TextView payeeTxtView = (TextView) hLinearLayoutItemInfo.getChildAt(3);
                TextView itemBoughtTxtView = (TextView) hLinearLayoutItemInfo.getChildAt(0);
                TextView itemCategoryTxtView = (TextView) hLinearLayoutItemInfo.getChildAt(1);
                TextView amountTxtView = (TextView) hLinearLayoutItemInfo.getChildAt(2);

                if(allPaymentOptions.contains(paymentOptString) || paymentOptString.equals("Cash")){
                    LinearLayout paymentOptLayout = (LinearLayout) findViewById(R.id.PaymentOptLayout);
                    for(int x = 0; x<paymentOptLayout.getChildCount()-1; x++){
                        LinearLayout tmpLayout = (LinearLayout) paymentOptLayout.getChildAt(x);
                        TextView tmpTextView = (TextView) tmpLayout.getChildAt(0);
                        if(tmpTextView.getText().toString().equals(paymentOptString)){
                            for(int y = 0; y < paymentOptLayout.getChildCount() - 1; y++){  //not including first TextView Cash and last Button that adds payment options.
                                LinearLayout tempLayout2 = (LinearLayout) paymentOptLayout.getChildAt(y);
                                TextView tempTextView2 = (TextView) tempLayout2.getChildAt(0);
                                tempTextView2.setBackgroundResource(0);
                            }
                            tmpTextView.setBackgroundResource(R.drawable.border);
                        }
                    }
                }
                else{
                    createPaymentOpt(paymentOptString);
                }

                itemBoughtEditTxt.setText(itemBoughtTxtView.getText());
                itemCategoryEditTxt.setText(itemCategoryTxtView.getText());
                DecimalFormat form = new DecimalFormat("0.00", new DecimalFormatSymbols(Locale.UK));
                double a = Double.parseDouble(amountTxtView.getText().subSequence(1, amountTxtView.getText().length()).toString());
                amountEditTxt.setText(form.format(a));
                payeeEditTxt.setText(payeeTxtView.getText());
                dateEditTxt.setText(dateTxtView.getText());
            }
        });
        hLinearLayout.addView(hLinearLayoutItemInfo);


        final TextView itemNameTxtView = new TextView(this);
        paramsTextViews.setMargins(10, 5, 10, 5);
        itemNameTxtView.setLayoutParams(paramsTextViews);
        itemNameTxtView.setPadding(15, 0, 0, 0);
        itemNameTxtView.setText(itemBoughtString);
        itemNameTxtView.setTextSize(24);
        itemNameTxtView.setHorizontallyScrolling(true);
        itemNameTxtView.setMovementMethod(new ScrollingMovementMethod());
        itemNameTxtView.setBackgroundResource(R.drawable.border);
        hLinearLayoutItemInfo.addView(itemNameTxtView);
        itemNameTxtView.isClickable();
        itemNameTxtView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                TextView dateEditTxt = (TextView) findViewById(R.id.DateTextView);
                EditText payeeEditTxt = (EditText) findViewById(R.id.PayeeEditTxt);
                EditText itemBoughtEditTxt = (EditText) findViewById(R.id.ItemBoughtEditTxt);
                EditText itemCategoryEditTxt = (EditText) findViewById(R.id.ItemCategoryEditTxt);
                EditText amountEditTxt = (EditText) findViewById(R.id.AmountEditTxt);

                TextView dateTxtView = (TextView) hLinearLayoutItemInfo.getChildAt(4);
                TextView payeeTxtView = (TextView) hLinearLayoutItemInfo.getChildAt(3);
                TextView itemBoughtTxtView = (TextView) hLinearLayoutItemInfo.getChildAt(0);
                TextView itemCategoryTxtView = (TextView) hLinearLayoutItemInfo.getChildAt(1);
                TextView amountTxtView = (TextView) hLinearLayoutItemInfo.getChildAt(2);

                if(allPaymentOptions.contains(paymentOptString) || paymentOptString.equals("Cash")){
                    LinearLayout paymentOptLayout = (LinearLayout) findViewById(R.id.PaymentOptLayout);
                    for(int x = 0; x<paymentOptLayout.getChildCount()-1; x++){
                        LinearLayout tmpLayout = (LinearLayout) paymentOptLayout.getChildAt(x);
                        TextView tmpTextView = (TextView) tmpLayout.getChildAt(0);
                        if(tmpTextView.getText().toString().equals(paymentOptString)){
                            for(int y = 0; y < paymentOptLayout.getChildCount() - 1; y++){  //not including first TextView Cash and last Button that adds payment options.
                                LinearLayout tempLayout2 = (LinearLayout) paymentOptLayout.getChildAt(y);
                                TextView tempTextView2 = (TextView) tempLayout2.getChildAt(0);
                                tempTextView2.setBackgroundResource(0);
                            }
                            tmpTextView.setBackgroundResource(R.drawable.border);
                        }
                    }
                }
                else{
                    createPaymentOpt(paymentOptString);
                }

                itemBoughtEditTxt.setText(itemBoughtTxtView.getText());
                itemCategoryEditTxt.setText(itemCategoryTxtView.getText());
                DecimalFormat form = new DecimalFormat("0.00", new DecimalFormatSymbols(Locale.UK));
                double a = Double.parseDouble(amountTxtView.getText().subSequence(1, amountTxtView.getText().length()).toString());
                amountEditTxt.setText(form.format(a));
                payeeEditTxt.setText(payeeTxtView.getText());
                dateEditTxt.setText(dateTxtView.getText());
            }
        });

        final TextView itemCategoryTxtView = new TextView(this);
        paramsTextViews.setMargins(0, 5, 0, 5);
        itemCategoryTxtView.setLayoutParams(paramsTextViews);
        itemCategoryTxtView.setPadding(15, 0, 0, 0);
        itemCategoryTxtView.setTextSize(24);
        itemCategoryTxtView.setHorizontallyScrolling(true);
        itemCategoryTxtView.setMovementMethod(new ScrollingMovementMethod());
        itemCategoryTxtView.setText(itemCategoryString);
        itemCategoryTxtView.setBackgroundResource(R.drawable.border);
        hLinearLayoutItemInfo.addView(itemCategoryTxtView);
        itemCategoryTxtView.isClickable();
        itemCategoryTxtView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                TextView dateEditTxt = (TextView) findViewById(R.id.DateTextView);
                EditText payeeEditTxt = (EditText) findViewById(R.id.PayeeEditTxt);
                EditText itemBoughtEditTxt = (EditText) findViewById(R.id.ItemBoughtEditTxt);
                EditText itemCategoryEditTxt = (EditText) findViewById(R.id.ItemCategoryEditTxt);
                EditText amountEditTxt = (EditText) findViewById(R.id.AmountEditTxt);

                TextView dateTxtView = (TextView) hLinearLayoutItemInfo.getChildAt(4);
                TextView payeeTxtView = (TextView) hLinearLayoutItemInfo.getChildAt(3);
                TextView itemBoughtTxtView = (TextView) hLinearLayoutItemInfo.getChildAt(0);
                TextView itemCategoryTxtView = (TextView) hLinearLayoutItemInfo.getChildAt(1);
                TextView amountTxtView = (TextView) hLinearLayoutItemInfo.getChildAt(2);

                if(allPaymentOptions.contains(paymentOptString) || paymentOptString.equals("Cash")){
                    LinearLayout paymentOptLayout = (LinearLayout) findViewById(R.id.PaymentOptLayout);
                    for(int x = 0; x<paymentOptLayout.getChildCount()-1; x++){
                        LinearLayout tmpLayout = (LinearLayout) paymentOptLayout.getChildAt(x);
                        TextView tmpTextView = (TextView) tmpLayout.getChildAt(0);
                        if(tmpTextView.getText().toString().equals(paymentOptString)){
                            for(int y = 0; y < paymentOptLayout.getChildCount() - 1; y++){  //not including first TextView Cash and last Button that adds payment options.
                                LinearLayout tempLayout2 = (LinearLayout) paymentOptLayout.getChildAt(y);
                                TextView tempTextView2 = (TextView) tempLayout2.getChildAt(0);
                                tempTextView2.setBackgroundResource(0);
                            }
                            tmpTextView.setBackgroundResource(R.drawable.border);
                        }
                    }
                }
                else{
                    createPaymentOpt(paymentOptString);
                }

                itemBoughtEditTxt.setText(itemBoughtTxtView.getText());
                itemCategoryEditTxt.setText(itemCategoryTxtView.getText());
                DecimalFormat form = new DecimalFormat("0.00", new DecimalFormatSymbols(Locale.UK));
                double a = Double.parseDouble(amountTxtView.getText().subSequence(1, amountTxtView.getText().length()).toString());
                amountEditTxt.setText(form.format(a));
                payeeEditTxt.setText(payeeTxtView.getText());
                dateEditTxt.setText(dateTxtView.getText());
            }
        });

        final TextView amountTxtView = new TextView(this);
        paramsTextViews.setMargins(10, 5, 10, 5);
        amountTxtView.setLayoutParams(paramsTextViews);
        amountTxtView.setPadding(15, 0, 0, 0);
        amountTxtView.setTextSize(24);
        amountTxtView.setHorizontallyScrolling(true);
        amountTxtView.setMovementMethod(new ScrollingMovementMethod());
        amountTxtView.setText("£" + amountString);
        amountTxtView.setBackgroundResource(R.drawable.border);
        hLinearLayoutItemInfo.addView(amountTxtView);
        amountTxtView.isClickable();
        amountTxtView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                TextView dateEditTxt = (TextView) findViewById(R.id.DateTextView);
                EditText payeeEditTxt = (EditText) findViewById(R.id.PayeeEditTxt);
                EditText itemBoughtEditTxt = (EditText) findViewById(R.id.ItemBoughtEditTxt);
                EditText itemCategoryEditTxt = (EditText) findViewById(R.id.ItemCategoryEditTxt);
                EditText amountEditTxt = (EditText) findViewById(R.id.AmountEditTxt);

                TextView dateTxtView = (TextView) hLinearLayoutItemInfo.getChildAt(4);
                TextView payeeTxtView = (TextView) hLinearLayoutItemInfo.getChildAt(3);
                TextView itemBoughtTxtView = (TextView) hLinearLayoutItemInfo.getChildAt(0);
                TextView itemCategoryTxtView = (TextView) hLinearLayoutItemInfo.getChildAt(1);
                TextView amountTxtView = (TextView) hLinearLayoutItemInfo.getChildAt(2);

                if(allPaymentOptions.contains(paymentOptString) || paymentOptString.equals("Cash")){
                    LinearLayout paymentOptLayout = (LinearLayout) findViewById(R.id.PaymentOptLayout);
                    for(int x = 0; x<paymentOptLayout.getChildCount()-1; x++){
                        LinearLayout tmpLayout = (LinearLayout) paymentOptLayout.getChildAt(x);
                        TextView tmpTextView = (TextView) tmpLayout.getChildAt(0);
                        if(tmpTextView.getText().toString().equals(paymentOptString)){
                            for(int y = 0; y < paymentOptLayout.getChildCount() - 1; y++){  //not including first TextView Cash and last Button that adds payment options.
                                LinearLayout tempLayout2 = (LinearLayout) paymentOptLayout.getChildAt(y);
                                TextView tempTextView2 = (TextView) tempLayout2.getChildAt(0);
                                tempTextView2.setBackgroundResource(0);
                            }
                            tmpTextView.setBackgroundResource(R.drawable.border);
                        }
                    }
                }
                else{
                    createPaymentOpt(paymentOptString);
                }

                itemBoughtEditTxt.setText(itemBoughtTxtView.getText());
                itemCategoryEditTxt.setText(itemCategoryTxtView.getText());
                DecimalFormat form = new DecimalFormat("0.00", new DecimalFormatSymbols(Locale.UK));
                double a = Double.parseDouble(amountTxtView.getText().subSequence(1, amountTxtView.getText().length()).toString());
                amountEditTxt.setText(form.format(a));
                payeeEditTxt.setText(payeeTxtView.getText());
                dateEditTxt.setText(dateTxtView.getText());
            }
        });

        //Invisible TextViews for being able to easily access all item information
        final TextView payeeTxtView = new TextView(this);
        payeeTxtView.setText(payeeString);
        payeeTxtView.setVisibility(View.GONE);
        hLinearLayoutItemInfo.addView(payeeTxtView);

        final TextView dateTxtView = new TextView(this);
        dateTxtView.setText(dateString);
        dateTxtView.setVisibility(View.GONE);
        hLinearLayoutItemInfo.addView(dateTxtView);

        final TextView paymentOptTxtView = new TextView(this);
        paymentOptTxtView.setText(paymentOptString);   //TODO change payment option to slider selected.
        paymentOptTxtView.setVisibility(View.GONE);
        hLinearLayoutItemInfo.addView(paymentOptTxtView);

        allAddedItemsLayout.addView(hLinearLayout, 0);
    }

    public String inputsToString(){
        String finalString = "";
        LinearLayout allAddedItemsLayout = (LinearLayout) findViewById(R.id.AllAddedItemsLayout);

        ArrayList<ViewGroup> allItemLayouts = (ArrayList<ViewGroup>) getViewsByTag(allAddedItemsLayout, "Item Info");

        for(ViewGroup viewGroup: allItemLayouts){
            //index order is important, based on earlier code in function 'addCurrentItem()'.
            TextView itemNameTextViews = (TextView) viewGroup.getChildAt(0);
            TextView itemCategoryTextViews = (TextView) viewGroup.getChildAt(1);
            TextView amountTextViews = (TextView) viewGroup.getChildAt(2);
            TextView payeeTextViews = (TextView) viewGroup.getChildAt(3);
            TextView dateTextViews = (TextView) viewGroup.getChildAt(4);
            TextView paymentOptTextViews = (TextView) viewGroup.getChildAt(5);

            finalString = finalString.concat(itemNameTextViews.getText().toString() + "\n" + itemCategoryTextViews.getText().toString() +
                    "\n" + amountTextViews.getText().toString() + "\n" + payeeTextViews.getText().toString() + "\n" +
                    dateTextViews.getText().toString() + "\n" + paymentOptTextViews.getText().toString()+ "\n");
        }
        return finalString;
    }

    private static ArrayList<ViewGroup> getViewsByTag(ViewGroup root, String tag){
        ArrayList<ViewGroup> views = new ArrayList<ViewGroup>();
        final int childCount = root.getChildCount();
        for (int i = 0; i < childCount; i++) {
            final View child = root.getChildAt(i);
            if(child instanceof ImageView || child instanceof TextView){ }  //Without this, causes error because ImageView and TextView can't be cast to ViewGroups because they can't have children.
            else if (child instanceof View) {
                views.addAll(getViewsByTag((ViewGroup) child, tag));
            }
            final Object tagObj = child.getTag();
            if (tagObj != null && tagObj.equals(tag)) {
                final ViewGroup addChild = (ViewGroup) child;
                views.add(addChild);
            }
        }
        return views;
    }

    public void ConfirmPopupWindowClick(View view) {
        // inflate the layout of the popup window
        LayoutInflater inflater = (LayoutInflater)
                getSystemService(LAYOUT_INFLATER_SERVICE);
        View popupView = inflater.inflate(R.layout.activity_new_payment_option_popup, null);

        // create the popup window
        int width = LinearLayout.LayoutParams.WRAP_CONTENT;
        int height = LinearLayout.LayoutParams.WRAP_CONTENT;
        boolean focusable = true; // lets taps outside the popup also dismiss it
        final PopupWindow popupWindow = new PopupWindow(popupView, width, height, focusable);

        // show the popup window
        // which view you pass in doesn't matter, it is only used for the window tolken
        popupWindow.showAtLocation(view, Gravity.CENTER, 0, 0);
        Button confirmBtn = (Button) popupView.findViewById(R.id.confirmBtn);
        EditText paymentOptEditText = popupView.findViewById(R.id.PaymentOptEditText);

        confirmBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View popupView) {
                createPaymentOpt(paymentOptEditText.getText().toString());
                allPaymentOptions.add(paymentOptEditText.getText().toString());
                popupWindow.dismiss();
            }
        });
    }

    private void createPaymentOpt(String paymentOptString){
        LinearLayout paymentOptLayout = (LinearLayout) findViewById(R.id.PaymentOptLayout);
        Boolean payOptInList = false;
        for(int y = 0; y < paymentOptLayout.getChildCount() - 1; y++){
            LinearLayout tempLayout2 = (LinearLayout) paymentOptLayout.getChildAt(y);
            TextView tempTextView2 = (TextView) tempLayout2.getChildAt(0);
            tempTextView2.setBackgroundResource(0);
            if(tempTextView2.getText().toString().equals(paymentOptString)){
                tempTextView2.setBackgroundResource(R.drawable.border);
                paymentOpt = tempTextView2.getText().toString();
                payOptInList = true;
            }
        }
        if(!payOptInList){
            LinearLayout.LayoutParams payOptInfoLayoutParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.MATCH_PARENT
            );
            LinearLayout hLayoutPaymentOptInfo = new LinearLayout(AddItems.this);
            hLayoutPaymentOptInfo.setLayoutParams(payOptInfoLayoutParams);
            hLayoutPaymentOptInfo.setGravity(Gravity.CENTER);
            paymentOptLayout.addView(hLayoutPaymentOptInfo, paymentOptLayout.getChildCount()-1);

            LinearLayout.LayoutParams textViewParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );
            TextView paymentOptTextView = new TextView(AddItems.this);
            paymentOptTextView.setTextSize(24);
            paymentOptTextView.setText(paymentOptString);
            paymentOptTextView.setLayoutParams(textViewParams);
            paymentOptTextView.setPadding(2, 0, 2, 0);
            paymentOptTextView.setClickable(true);
            paymentOptTextView.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    TextView cashPayOptTextView = (TextView) findViewById(R.id.CashPayOptTextView);
                    cashPayOptTextView.setBackgroundResource(0);
                    for(int x = 1; x < paymentOptLayout.getChildCount() - 1; x++){  //not including first TextView Cash and last Button that adds payment options.
                        LinearLayout tempLayout = (LinearLayout) paymentOptLayout.getChildAt(x);
                        TextView tempTextView = (TextView) tempLayout.getChildAt(0);
                        tempTextView.setBackgroundResource(0);
                    }
                    paymentOptTextView.setBackgroundResource(R.drawable.border);
                    paymentOpt = paymentOptTextView.getText().toString();
                }
            });
            hLayoutPaymentOptInfo.addView(paymentOptTextView);

            ImageButton deleteBtn = new ImageButton(AddItems.this);
            deleteBtn.setScaleType(ImageView.ScaleType.FIT_CENTER);
            deleteBtn.setImageDrawable(getResources().getDrawable(R.drawable.button_image_x));
            deleteBtn.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    if(paymentOpt.equals(paymentOptString)){
                        paymentOpt = "Cash";
                        TextView cashPayOptTextView = findViewById(R.id.CashPayOptTextView);
                        cashPayOptTextView.setBackgroundResource(R.drawable.border);
                    }
                    allPaymentOptions.remove(paymentOptString);
                    paymentOptLayout.removeView(hLayoutPaymentOptInfo);
                }
            });
            hLayoutPaymentOptInfo.addView(deleteBtn);
            for(int x = 0; x < paymentOptLayout.getChildCount() - 1; x++){  //not including first TextView Cash and last Button that adds payment options.
                LinearLayout tempLayout = (LinearLayout) paymentOptLayout.getChildAt(x);
                TextView tempTextView = (TextView) tempLayout.getChildAt(0);
                tempTextView.setBackgroundResource(0);
            }
            paymentOptTextView.setBackgroundResource(R.drawable.border);
            paymentOpt = paymentOptTextView.getText().toString();
        }

    }

    //The below function was taken from: https://stackoverflow.com/questions/1560788/how-to-check-internet-access-on-android-inetaddress-never-times-out
    //This function is used to return a Boolean on whether there is a working internet connection on the device.
    public boolean isOnline() {
        Runtime runtime = Runtime.getRuntime();
        try {
            Process ipProcess = runtime.exec("/system/bin/ping -c 1 8.8.8.8");
            int     exitValue = ipProcess.waitFor();
            return (exitValue == 0);
        }
        catch (IOException e)          { e.printStackTrace(); }
        catch (InterruptedException e) { e.printStackTrace(); }

        return false;
    }

    public void noInternetPopupWindowClick(View view) {
        // inflate the layout of the popup window
        LayoutInflater inflater = (LayoutInflater)
                getSystemService(LAYOUT_INFLATER_SERVICE);
        View popupView = inflater.inflate(R.layout.activity_no_internet_popup, null);

        // create the popup window
        int width = LinearLayout.LayoutParams.WRAP_CONTENT;
        int height = LinearLayout.LayoutParams.WRAP_CONTENT;
        boolean focusable = true; // lets taps outside the popup also dismiss it
        final PopupWindow popupWindow = new PopupWindow(popupView, width, height, focusable);

        // show the popup window
        // which view you pass in doesn't matter, it is only used for the window tolken
        popupWindow.showAtLocation(view, Gravity.CENTER, 0, 0);
        Button noBtn = (Button) popupView.findViewById(R.id.NoBtn);

        noBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View popupView) {
                popupWindow.dismiss();
            }
        });

        Button yesBtn = (Button) popupView.findViewById(R.id.YesBtn);

        yesBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View popupView) {
                addedItemsString = "";
                MainActivity.submitBtnClicked = true;
                inputsToStringResult = inputsToString();
                startActivity(new Intent(AddItems.this, RetrieveContentsActivity.class));
                popupWindow.dismiss();
            }
        });
    }

    public void onBackPressed(){
        startActivity(new Intent(this, MainActivity.class));
    }
}
