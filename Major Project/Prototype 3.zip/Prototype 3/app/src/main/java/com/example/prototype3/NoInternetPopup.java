package com.example.prototype3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class NoInternetPopup extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_no_internet_popup);
    }
}
