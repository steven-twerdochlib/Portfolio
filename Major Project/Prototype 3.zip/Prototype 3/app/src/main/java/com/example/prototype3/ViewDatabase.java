package com.example.prototype3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Layout;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;

public class ViewDatabase extends AppCompatActivity {

    public ArrayList<String> itemList = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_database);

        Button filterBtn = (Button) findViewById(R.id.filterBtn);
        filterBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                ConfirmPopupWindowClick(v);
            }
        });

        itemList.add("Item 1");
        itemList.add("Item 2");
        itemList.add("Item 3");
        itemList.add("Item 4");
        itemList.add("Item 5");
        itemList.add("Item 6");
        itemList.add("Item 7");
        itemList.add("Item 8");
        itemList.add("Item 9");
        itemList.add("Item 10");
        itemList.add("Item 11");

        createLayoutDynamically();
    }

    private void createLayoutDynamically() {
        for (int i = 0; i < itemList.size(); i++) {

            LinearLayout.LayoutParams paramsTextViews = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    1.0f
            );

            final LinearLayout vLinearLayout = new LinearLayout(this);
            vLinearLayout.setId(i);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.MATCH_PARENT
            );
            params.setMargins(15, 15, 15, 15);
            vLinearLayout.setLayoutParams(params);
            vLinearLayout.setBackgroundResource(R.drawable.border);
            vLinearLayout.setOrientation(LinearLayout.VERTICAL);

            final LinearLayout hLinearLayout = new LinearLayout(this);
            hLinearLayout.setId(i);
            hLinearLayout.setOrientation(LinearLayout.HORIZONTAL);
            hLinearLayout.setLayoutParams(paramsTextViews);
            vLinearLayout.addView(hLinearLayout);

            final TextView itemBoughtTextView = new TextView(this);
            itemBoughtTextView.setId(i);
            paramsTextViews.setMargins(15, 15, 15, 5);
            itemBoughtTextView.setLayoutParams(paramsTextViews);
            itemBoughtTextView.setPadding(15, 0, 0, 0);
            itemBoughtTextView.setText(itemList.get(i));
            itemBoughtTextView.setBackgroundResource(R.drawable.border);
            hLinearLayout.addView(itemBoughtTextView);

            final TextView itemCategoryTextView = new TextView(this);
            itemCategoryTextView.setId(i);
            itemCategoryTextView.setText(itemList.get(i));
            itemCategoryTextView.setBackgroundResource(R.drawable.border);
            itemCategoryTextView.setLayoutParams(paramsTextViews);
            itemCategoryTextView.setPadding(15, 0, 0, 0);
            hLinearLayout.addView(itemCategoryTextView);

            final TextView itemCostTextView = new TextView(this);
            itemCostTextView.setId(i);
            itemCostTextView.setText(itemList.get(i));
            itemCostTextView.setLayoutParams(paramsTextViews);
            itemCostTextView.setBackgroundResource(R.drawable.border);
            itemCostTextView.setPadding(15, 0, 0, 0);
            hLinearLayout.addView(itemCostTextView);

            final Button myButton = new Button(this);
            myButton.setId(i);
            myButton.setText("See More Info");
            myButton.setBackgroundResource(R.drawable.buttonborder);
            myButton.setLayoutParams(paramsTextViews);
            vLinearLayout.addView(myButton);

            LinearLayout itemsLayout = findViewById(R.id.ItemsLayout);
            itemsLayout.addView(vLinearLayout);

            myButton.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                }
            });
        }
    }

    public void ConfirmPopupWindowClick(View view) {
        // inflate the layout of the popup window
        LayoutInflater inflater = (LayoutInflater)
                getSystemService(LAYOUT_INFLATER_SERVICE);
        View popupView = inflater.inflate(R.layout.activity_filter_popup, null);

        // create the popup window
        int width = LinearLayout.LayoutParams.WRAP_CONTENT;
        int height = LinearLayout.LayoutParams.WRAP_CONTENT;
        boolean focusable = true; // lets taps outside the popup also dismiss it
        final PopupWindow popupWindow = new PopupWindow(popupView, width, height, focusable);

        // show the popup window
        // which view you pass in doesn't matter, it is only used for the window tolken
        popupWindow.showAtLocation(view, Gravity.CENTER, 0, 0);
        Button confirmBtn = (Button) popupView.findViewById(R.id.confirmBtn);
        confirmBtn.setOnClickListener(new View.OnClickListener() {

            public void onClick(View popupView) {
                popupWindow.dismiss();
            }
        });
    }
}
