package com.example.prototype3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class NewFilePopup extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_file_popup);
    }
}
