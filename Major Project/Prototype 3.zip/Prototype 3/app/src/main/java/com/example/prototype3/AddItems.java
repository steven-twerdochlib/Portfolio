package com.example.prototype3;

import android.os.Handler;
import android.preference.PreferenceScreen;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.DisplayMetrics;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.example.prototype3.MyAdaptor.*;

public class AddItems extends AppCompatActivity {

    private RecyclerView.Adapter mAdapter;
    private ArrayList<String> mDataset = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_items);

        mDataset.add("Cash");
        mDataset.add("Santander");
        mDataset.add("Nationwide");
        mDataset.add("Testing 1223344343141");

        final LinearLayoutManager layoutManager
                = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);

        RecyclerView payOptRecylcleView = (RecyclerView) findViewById(R.id.PaymentOptionScroll);
        payOptRecylcleView.setLayoutManager(layoutManager);

        mAdapter = new MyAdaptor(this, mDataset);
        payOptRecylcleView.setAdapter(mAdapter);
    }

}
